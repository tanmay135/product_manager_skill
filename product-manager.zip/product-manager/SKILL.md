---
name: product-manager
description: Comprehensive Product Requirements Document (PRD) creation skill for product managers. Use when users request help drafting PRDs, documenting features, conducting market research, competitive analysis, or creating detailed product specifications. Triggers on requests like "draft a PRD", "create product requirements", "analyze competitors", "research market for feature", or "document this feature".
---

# Product Manager Skill

Create comprehensive, research-backed Product Requirements Documents (PRDs) with market analysis, competitive research, and detailed specifications.

## Workflow Overview

When creating a PRD, follow these steps:

1. **Understand the Feature** - Gather context and clarify scope
2. **Market Research** - Research market landscape and opportunity
3. **Competitive Analysis** - Analyze competitors and identify differentiation
4. **Problem Discovery** - Document user pain points and business impact
5. **Solution Design** - Define proposed solution with user flows
6. **PRD Creation** - Draft comprehensive PRD document

## Step 1: Understand the Feature

Ask clarifying questions to understand:
- **Feature description**: What is being built?
- **Target users**: Who will use this?
- **Core problem**: What problem does it solve?
- **Success criteria**: How will we measure success?
- **Constraints**: Timeline, resources, technical limitations?
- **Context**: How does this fit into existing product?

If the user provides a brief description, probe deeper before proceeding to research.

## Step 2: Market Research

Use web_search to investigate:

**Market Landscape:**
- Market size and growth trends
- Industry reports and analyst perspectives
- Emerging trends in the space
- Total Addressable Market (TAM) estimates

**User Insights:**
- Common pain points discussed in forums/communities
- User reviews of related products
- Feature requests and complaints
- User behavior patterns and preferences

**Search Strategy:**
- Start broad: "[problem space] market size", "[industry] trends 2024"
- Go specific: "[specific problem] user complaints", "[feature type] adoption"
- Look for data: surveys, reports, statistics
- Find voices: Reddit, Twitter, community forums

See `references/market_research.md` for detailed guidance on research methods.

## Step 3: Competitive Analysis

Use web_search to research competitors:

**Identify Competitors:**
- Direct competitors (same solution)
- Indirect competitors (alternative approaches)
- Adjacent products (different but related)

**For Each Major Competitor, Research:**
- Core features and functionality
- Pricing and business model
- Market position and growth
- User reviews and sentiment (G2, Capterra, app stores)
- Strengths and weaknesses
- Recent product launches

**Synthesis:**
- Create comparison table (feature parity)
- Identify gaps in competitor offerings
- Find differentiation opportunities
- Note what they do well (best practices)

**Search Strategy:**
- "[competitor name] features", "[competitor] pricing"
- "[competitor] reviews", "[competitor] vs [competitor]"
- "alternatives to [competitor]", "[category] comparison"
- "[competitor] problems", "[competitor] complaints"

Use at least 5-10 web searches for thorough competitive analysis.

See `references/competitive_analysis.md` for comprehensive competitive research framework.

## Step 4: Problem Discovery

Based on research, document:

**User Pain Points:**
- Specific problems users face
- Frequency and severity
- Impact on workflow/outcomes
- Current workarounds

**Business Impact:**
- Revenue implications (lost deals, churn)
- Customer satisfaction impact
- Operational costs of current state
- Competitive disadvantage

**Evidence:**
- Quote research findings
- Cite user feedback
- Reference competitive gaps
- Include quantitative data when available

## Step 5: Solution Design

Define the proposed solution:

**High-Level Solution:**
- What are we building?
- How does it solve the problem?
- Why this approach vs. alternatives?

**Key Features:**
- Must-have (P0) features
- Should-have (P1) features  
- Nice-to-have (P2) features

**User Stories:**
- "As a [user type], I want to [action] so that [benefit]"
- Include primary and edge cases

**User Flows:**
- Create flow diagrams showing user journey
- Document decision points
- Include error/edge cases
- Use Mermaid syntax or ASCII diagrams

See `references/flow_diagrams.md` for guidance on creating effective diagrams.

## Step 6: PRD Creation

Create the PRD document using the template in `assets/prd_template.md`.

**Document Structure:**

1. **Executive Summary** - High-level overview and key metrics
2. **Problem Statement** - Current state, pain points, business impact
3. **Market Research & Competition** - Market landscape, competitive analysis, user research
4. **Proposed Solution** - Solution overview, features, user stories, user flows
5. **Why This Solution** - Business alignment, benefits, ROI, competitive advantage
6. **What We're Building** - Functional requirements, non-functional requirements, architecture, data model, UI/UX specs
7. **How We're Building It** - Implementation phases, timeline, resources, dependencies
8. **Success Metrics & KPIs** - Primary/secondary metrics, success criteria
9. **Risk Assessment** - Risks and mitigation strategies
10. **Launch & Go-to-Market** - Launch strategy, marketing, support
11. **Post-Launch Plan** - Monitoring, feedback, iteration
12. **Open Questions & Decisions** - Unresolved items
13. **Appendix** - Supporting materials and references

**Writing Guidelines:**

**Be Specific:**
- Use concrete examples, not abstract descriptions
- Include quantitative data when possible
- Provide clear acceptance criteria
- Define measurable success metrics

**Be Comprehensive:**
- Address why, what, and how thoroughly
- Include visual diagrams (user flows, architecture)
- Document edge cases and error handling
- Cover technical and non-technical requirements

**Be Structured:**
- Use tables for comparisons and data
- Use bullet points for lists
- Use flow diagrams for processes
- Use headers to organize sections

**Be Research-Backed:**
- Cite market research findings
- Reference competitive analysis
- Include user feedback and data
- Support claims with evidence

**Visual Elements:**

Include these throughout the PRD:

**Tables:**
- Competitive comparison matrices
- Feature prioritization
- Success metrics
- Risk assessment
- Timeline and milestones
- Resource allocation

**Flow Diagrams:**
- User flows (how users interact)
- System flows (how components interact)
- Decision trees (conditional logic)
- State diagrams (object lifecycle)

Use Mermaid syntax for diagrams:
```mermaid
graph TD
    A[Start] --> B{Decision}
    B -->|Yes| C[Action 1]
    B -->|No| D[Action 2]
    C --> E[End]
    D --> E
```

## Output Format

**For Simple Requests:**
Create a PRD document directly using the template.

**For Complex Features:**
1. First provide a summary of research findings
2. Discuss key decisions and trade-offs
3. Then create the comprehensive PRD document

**Always:**
- Create the PRD as a .docx file in /mnt/user-data/outputs/
- Use the docx skill for professional formatting
- Include table of contents
- Use proper heading hierarchy
- Format tables professionally

## Quality Checklist

Before finalizing the PRD, verify:

**Research Quality:**
- [ ] Conducted market research (5+ sources)
- [ ] Analyzed 3+ competitors thoroughly
- [ ] Identified user pain points with evidence
- [ ] Quantified business impact

**Solution Clarity:**
- [ ] Clear problem statement
- [ ] Well-defined solution approach
- [ ] Prioritized feature list
- [ ] User stories with acceptance criteria
- [ ] User flow diagrams

**Completeness:**
- [ ] Why: Business justification and ROI
- [ ] What: Detailed functional requirements
- [ ] How: Implementation approach and timeline
- [ ] Success metrics and KPIs defined
- [ ] Risks identified with mitigation

**Professional Quality:**
- [ ] Uses template structure
- [ ] Includes visual diagrams and tables
- [ ] Properly formatted (headings, spacing)
- [ ] Cites research sources
- [ ] Free of typos and errors

## Tips for Effective PRDs

**Start with Why:**
Always begin by clearly articulating the problem and business case before jumping to solutions.

**Be Opinionated:**
Make clear recommendations based on research. Don't just present options without guidance.

**Think in Phases:**
Break complex features into phases for incremental delivery and learning.

**Consider Trade-offs:**
Explicitly discuss trade-offs in approach, scope, and priorities.

**Make it Actionable:**
Ensure engineering, design, and other teams have what they need to execute.

**Balance Detail:**
Provide enough detail for clarity, but not so much that it becomes outdated quickly.

**Iterate:**
PRDs are living documents. Be prepared to update based on feedback and new learnings.

## Common Pitfalls to Avoid

**Don't:**
- Create PRDs without research (no guessing)
- Skip competitive analysis
- Ignore edge cases and error handling
- Write vague requirements without acceptance criteria
- Forget to define success metrics
- Over-specify implementation details (let eng decide)
- Make PRDs so long they're not read

**Do:**
- Ground everything in user needs and research
- Be specific and measurable
- Include visual aids (diagrams, tables)
- Define clear success criteria
- Consider risks and mitigation
- Make it skimmable with good structure
- Update PRD as decisions are made

## Examples

**Good Problem Statement:**
"Users spend an average of 15 minutes per day manually copying data between systems (based on time-tracking data and user interviews). This leads to 20% data entry errors and frustration (NPS -15 for this workflow). Competitors X and Y offer automated syncing, which is the #1 reason prospects choose them (sales data)."

**Bad Problem Statement:**
"Users have trouble with data entry and want better tools."

**Good User Story:**
"As a sales manager, I want to automatically sync customer data from CRM to reporting dashboard so that I can access up-to-date metrics without manual exports (currently done 3x/week, 20 min each)."

**Bad User Story:**
"As a user, I want better data so that I can do my job."

## Additional Resources

- **Market Research Guide**: See `references/market_research.md`
- **Competitive Analysis Guide**: See `references/competitive_analysis.md`
- **Flow Diagram Guide**: See `references/flow_diagrams.md`
- **PRD Template**: See `assets/prd_template.md`
