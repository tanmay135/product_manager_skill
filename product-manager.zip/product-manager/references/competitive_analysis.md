# Competitive Analysis Guide

## How to Conduct Competitive Analysis

### 1. Identify Competitors

**Direct Competitors:**
- Companies solving the same problem in similar ways
- Target the same customer segments
- Compete for the same budget

**Indirect Competitors:**
- Alternative solutions to the same problem
- Different approaches or methodologies
- Adjacent products users might choose instead

**Emerging Competitors:**
- Startups in the space
- New entrants from adjacent markets
- Potential disruptors

### 2. Research Framework

For each competitor, gather information on:

**Product & Features:**
- Core functionality
- Unique features
- User experience quality
- Platform availability (web, mobile, desktop)
- Integration capabilities
- Recent feature launches

**Market Position:**
- Target market and customer segments
- Market share (if available)
- Growth trajectory
- Geographic presence
- Brand strength

**Pricing & Business Model:**
- Pricing tiers and structure
- Free vs. paid features
- Enterprise offerings
- Revenue model (subscription, usage-based, one-time)

**Go-to-Market:**
- Marketing channels
- Sales approach (self-serve, sales-led, hybrid)
- Partnership strategy
- Customer acquisition tactics

**Technical Architecture:**
- Technology stack (if known)
- Performance characteristics
- Security and compliance
- API availability

**Customer Feedback:**
- Review sentiment (G2, Capterra, app stores)
- Common complaints
- Praised features
- NPS or satisfaction scores (if available)

### 3. Analysis Framework

**SWOT Analysis for Each Competitor:**

| Strengths | Weaknesses |
|-----------|------------|
| What they do well | Where they fall short |
| Competitive advantages | Vulnerabilities |

| Opportunities | Threats |
|---------------|---------|
| Market gaps they could fill | Risks to their business |
| Growth potential | Emerging competition |

**Feature Comparison Matrix:**

| Feature | Us | Competitor 1 | Competitor 2 | Competitor 3 |
|---------|-----|--------------|--------------|--------------|
| [Feature 1] | ✓/✗/Partial | ✓/✗/Partial | ✓/✗/Partial | ✓/✗/Partial |
| [Feature 2] | ✓/✗/Partial | ✓/✗/Partial | ✓/✗/Partial | ✓/✗/Partial |

### 4. Key Questions to Answer

1. **What do competitors do better than us?**
   - Identify best-in-class features
   - Understand why customers choose them

2. **What gaps exist in competitor offerings?**
   - Unmet customer needs
   - Feature requests in their communities
   - Opportunities for differentiation

3. **What can we learn from their mistakes?**
   - Failed product launches
   - Negative customer feedback
   - Pivots or discontinued features

4. **What trends are emerging?**
   - Common feature additions
   - New categories being created
   - Market consolidation or fragmentation

5. **How do we differentiate?**
   - Unique value propositions
   - Superior execution opportunities
   - Underserved segments

### 5. Information Sources

**Primary Sources:**
- Direct product testing (sign up for trials)
- Customer interviews (especially their former customers)
- Sales conversations (what prospects compare us to)

**Secondary Sources:**
- Company websites and blogs
- Product documentation
- Press releases and news articles
- Social media presence
- Review sites (G2, Capterra, TrustRadius)
- App store reviews
- Industry reports and analyst research

**Community Sources:**
- Reddit discussions
- Twitter conversations
- Industry forums
- Customer community forums
- Developer communities

### 6. Presenting Competitive Insights

**Executive Summary Format:**
```
[Competitor Name] is our strongest competitor in [market segment].

Key Strengths:
- [Strength 1]
- [Strength 2]

Key Weaknesses:
- [Weakness 1]
- [Weakness 2]

Differentiation Opportunity:
[How we can position against them]
```

**Visual Presentation:**
- Positioning maps (feature richness vs. ease of use)
- Market share charts
- Feature parity matrices
- Pricing comparison tables

### 7. Competitive Intelligence Maintenance

**Regular Updates:**
- Monthly: Quick scan of major competitors
- Quarterly: Deep dive on top 3-5 competitors
- Ad-hoc: When competitors launch major features

**Tracking System:**
- Maintain competitive tracking spreadsheet
- Set up Google Alerts for competitors
- Monitor their social media and blogs
- Subscribe to their newsletters
- Join their user communities

### 8. Ethical Considerations

**Do:**
- Use publicly available information
- Sign up for trials legitimately
- Respect their intellectual property
- Focus on learning and improvement

**Don't:**
- Misrepresent yourself to access information
- Violate terms of service
- Copy features directly without adding value
- Share confidential information obtained improperly
