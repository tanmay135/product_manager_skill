# Flow Diagrams and Visual Documentation

## When to Use Different Diagram Types

### 1. User Flow Diagrams
**Purpose:** Show step-by-step user journey through a feature

**When to Use:**
- Documenting user interactions
- Identifying decision points
- Planning UX improvements
- Communicating with designers

**Format:**
```
[Entry Point] → [Action] → [Decision?] → [Action] → [Outcome]
                              ↓
                         [Alternative Path]
```

**Example:**
```
Login Page → Enter Credentials → Valid? → Dashboard → Success
                                   ↓ No
                              Error Message → Retry
```

### 2. System Flow Diagrams
**Purpose:** Show data and process flow through technical systems

**When to Use:**
- Explaining technical architecture
- Planning integrations
- Documenting API flows
- System design discussions

**Format:**
```
[Component A] --data--> [Component B] --process--> [Component C]
      ↓                       ↑
   [Database] ←-----------[Queue]
```

### 3. Decision Trees
**Purpose:** Map out conditional logic and branching paths

**When to Use:**
- Complex business logic
- Approval workflows
- Rule-based systems
- Troubleshooting flows

**Format:**
```
Start → Condition 1?
           ↓ Yes        ↓ No
        Action A    Condition 2?
                       ↓ Yes  ↓ No
                     Action B  Action C
```

### 4. Swimlane Diagrams
**Purpose:** Show processes across different actors or systems

**When to Use:**
- Cross-functional workflows
- Handoff documentation
- Process optimization
- Stakeholder communication

**Format:**
```
User:      [Action] → [Wait] -----→ [Receive]
                        ↓
System:              [Process] → [Send]
                        ↓
Database:           [Store]
```

### 5. State Diagrams
**Purpose:** Show different states and transitions

**When to Use:**
- Object lifecycle
- Order/request status
- Complex state management

**Format:**
```
[Draft] --submit--> [In Review] --approve--> [Published]
   ↓                    ↓                         ↓
[Deleted]          [Rejected] ←-----------[Archived]
```

## Creating Effective Diagrams

### General Best Practices

**Clarity:**
- Use consistent shapes and symbols
- Label all arrows and transitions
- Keep text concise
- Avoid crossing lines when possible
- Use colors meaningfully (not just decoration)

**Completeness:**
- Show all major paths
- Include error/edge cases
- Document happy path and alternatives
- Note external dependencies

**Simplicity:**
- One diagram = one concept
- Break complex flows into multiple diagrams
- Use hierarchical levels (high-level → detailed)
- Hide implementation details when showing concepts

### Standard Symbols

**Common Shapes:**
- **Rectangle:** Process/Action
- **Diamond:** Decision point
- **Rounded Rectangle:** Start/End
- **Cylinder:** Database
- **Cloud:** External service
- **Parallelogram:** Input/Output
- **Circle:** Connector (continued on another diagram)

**Arrow Types:**
- **→ Solid arrow:** Main flow/data
- **⇢ Dashed arrow:** Alternative/conditional
- **↔ Double arrow:** Bidirectional
- **⟿ Thick arrow:** Primary path

### Diagram Complexity Guidelines

**Simple diagrams (5-10 elements):**
- Can be inline in PRD
- Good for high-level overview
- Use ASCII or simple markdown

**Medium complexity (10-25 elements):**
- Create separate diagram file
- Reference in PRD
- Use diagramming tool (Mermaid, Lucidchart)

**High complexity (25+ elements):**
- Break into multiple diagrams
- Create hierarchy (overview → details)
- Consider interactive tools

## Text-Based Diagram Formats

### Mermaid Syntax (Recommended)

**Flow Diagram:**
```mermaid
graph TD
    A[Start] --> B{Decision}
    B -->|Yes| C[Action 1]
    B -->|No| D[Action 2]
    C --> E[End]
    D --> E
```

**Sequence Diagram:**
```mermaid
sequenceDiagram
    User->>System: Request
    System->>Database: Query
    Database-->>System: Result
    System-->>User: Response
```

**State Diagram:**
```mermaid
stateDiagram-v2
    [*] --> Draft
    Draft --> InReview: Submit
    InReview --> Approved: Accept
    InReview --> Draft: Reject
    Approved --> [*]
```

### ASCII Art (Simple Cases)

**Linear Flow:**
```
Step 1 → Step 2 → Step 3 → Complete
```

**Branching:**
```
         ┌─→ Path A → Result A
Start ───┤
         └─→ Path B → Result B
```

**Cyclical:**
```
   ┌──────────────┐
   ↓              │
Start → Action → Decision?
                 │
                 └─→ End
```

## Integration with PRD

### Where to Include Diagrams

**Section 4 (Proposed Solution):**
- User flow diagrams
- Feature interaction flows

**Section 6 (What We're Building):**
- System architecture diagrams
- Data flow diagrams
- State diagrams

**Section 7 (How We're Building):**
- Implementation phase flows
- Deployment diagrams
- Integration flows

### Diagram Documentation

Always include with each diagram:
1. **Title:** Clear description of what's shown
2. **Legend:** If using custom symbols
3. **Context:** Brief explanation of the diagram
4. **Assumptions:** Any constraints or simplifications
5. **Version/Date:** For change tracking

**Example:**
```markdown
### User Authentication Flow

**Description:** This diagram shows how users authenticate and access protected resources.

**Assumptions:**
- Users have already registered
- OAuth tokens expire after 24 hours
- Password resets handled separately

[Diagram here]

**Key Decision Points:**
- Token validity check determines if re-authentication needed
- MFA requirement based on user security settings
```

## Tools for Creating Diagrams

**In-Document (Recommended):**
- Mermaid syntax (renders in markdown)
- ASCII art (simple cases)
- PlantUML (for complex technical diagrams)

**External Tools:**
- Lucidchart (collaborative, feature-rich)
- Draw.io/Diagrams.net (free, open-source)
- Figma (for UI flows and design integration)
- Whimsical (fast, simple, beautiful)

**For PRDs:**
- Prefer text-based formats (Mermaid) when possible
- Export to PNG/SVG for final PRDs
- Include source in appendix for future editing
- Ensure diagrams are version-controlled

## Example: Complete Flow Documentation

```markdown
## 4.4 User Flow: Feature Creation

### High-Level Overview
```
User Dashboard → Create New → Configure → Preview → Publish → Success
                               ↓ Cancel
                           Back to Dashboard
```

### Detailed Flow

```mermaid
graph TD
    A[Dashboard] -->|Click Create| B[Feature Form]
    B -->|Fill Details| C{Validation}
    C -->|Invalid| B
    C -->|Valid| D[Preview Screen]
    D -->|Edit| B
    D -->|Cancel| A
    D -->|Publish| E{Permissions?}
    E -->|No Permission| F[Error Message]
    E -->|Authorized| G[Publishing]
    G --> H{Success?}
    H -->|Yes| I[Success Page]
    H -->|No| J[Error Handling]
    J --> D
    F --> A
    I --> A
```

**Description:** This flow shows the complete journey from initiating feature creation to successful publication.

**Key Decision Points:**
1. **Validation (C):** Checks for required fields and format
2. **Permissions (E):** Verifies user authorization
3. **Success (H):** Confirms backend processing completed

**Edge Cases:**
- Validation failures return user to form with error messages
- Permission errors redirect to dashboard with notification
- Publishing failures allow retry without losing data

**Performance Requirements:**
- Validation: < 100ms
- Publishing: < 2s for 90th percentile
- Preview generation: < 500ms
```

## Common Mistakes to Avoid

**Don't:**
- Create overly complex diagrams that require explanation
- Use inconsistent notation within same document
- Omit error/edge case paths
- Make diagrams so detailed they become outdated quickly
- Use diagrams when simple text would suffice

**Do:**
- Test if a non-technical person can understand it
- Include a legend if using custom symbols
- Version control diagram sources
- Update diagrams when implementation changes
- Use hierarchy (overview → detailed views)
