# Market Research Guide

## Overview

Effective market research combines quantitative data with qualitative insights to understand:
- Market size and opportunity
- Customer needs and behaviors
- Product-market fit
- Pricing and positioning
- Go-to-market strategy

## Research Methods

### 1. User Surveys

**When to Use:**
- Validate hypotheses at scale
- Measure satisfaction and sentiment
- Prioritize features
- Understand demographics

**Survey Design Best Practices:**
- Keep surveys short (5-10 minutes)
- Use a mix of question types (multiple choice, rating scales, open-ended)
- Avoid leading questions
- Include screening questions
- Test with small group first

**Sample Questions:**
- "How often do you [use feature/face problem]?" (Frequency)
- "On a scale of 1-5, how satisfied are you with [aspect]?" (Satisfaction)
- "What would you use instead if this product didn't exist?" (Alternatives)
- "What's the biggest challenge you face when [doing task]?" (Pain points)

**Distribution Channels:**
- Email to existing users
- In-app prompts
- Social media
- User communities
- Paid survey panels

### 2. User Interviews

**When to Use:**
- Understand "why" behind behaviors
- Explore complex problems
- Generate new insights
- Build empathy with users

**Interview Structure:**
- Introduction (2 min): Build rapport
- Background (5 min): Understand context
- Deep dive (30-40 min): Explore topic
- Wrap-up (3 min): Clarify and thank

**Interview Techniques:**
- Ask open-ended questions
- Use "why" and "tell me more" to probe deeper
- Listen more than you talk (80/20 rule)
- Look for emotional cues
- Ask for specific examples, not generalizations
- Avoid pitching your solution

**Sample Question Flow:**
```
1. "Tell me about the last time you [encountered problem]"
2. "What did you try to solve it?"
3. "How did that work out?"
4. "What would an ideal solution look like?"
5. "What concerns would you have about [proposed solution]?"
```

### 3. Usage Analytics

**Key Metrics to Analyze:**
- User engagement (DAU, MAU, session duration)
- Feature adoption and usage patterns
- User flows and drop-off points
- Cohort retention
- Conversion funnels

**Analysis Approaches:**
- Segmentation analysis (power users vs. casual)
- Funnel analysis (where users drop off)
- Cohort analysis (how behavior changes over time)
- A/B test results
- Heat maps and session recordings

### 4. Market Sizing

**Top-Down Approach:**
```
Total Market → Addressable Market → Target Market → Obtainable Market

Example:
- Total market: All businesses (30M)
- Serviceable market: SMBs with 10-500 employees (5M)
- Target market: SMBs in specific industries (1M)
- Obtainable: Realistic capture in 3 years (50K = 5%)
```

**Bottom-Up Approach:**
```
Customer count × Revenue per customer × Market penetration

Example:
- 1,000 paying customers today
- $5,000 average annual revenue
- Growing 200% YoY
- Year 3 projection: 9,000 customers × $5,000 = $45M
```

**TAM, SAM, SOM Framework:**
- **TAM (Total Addressable Market):** Total market demand
- **SAM (Serviceable Addressable Market):** Segment you can reach
- **SOM (Serviceable Obtainable Market):** Realistic capture in timeframe

### 5. Voice of Customer (VoC)

**Sources:**
- Support tickets and inquiries
- Sales call notes
- Churn surveys and exit interviews
- Feature requests
- Community forum discussions
- Social media mentions
- Review sites

**Analysis Process:**
1. Collect feedback from all sources
2. Categorize by theme (pain points, feature requests, bugs)
3. Quantify frequency and severity
4. Identify patterns and trends
5. Translate to product requirements

**Feedback Categorization:**
- **Pain points:** Current frustrations
- **Unmet needs:** Gaps in solution
- **Workarounds:** How users compensate
- **Desired outcomes:** End goals
- **Emotional responses:** How they feel

### 6. Competitive Intelligence

See competitive_analysis.md for detailed guidance.

**Quick Framework:**
- Who are the alternatives users consider?
- What do they choose and why?
- What complaints do they have?
- Where are the gaps?

## Synthesis & Insights

### Translating Research into Requirements

**From Research to Product:**
1. **Pattern Recognition:** Look for recurring themes across multiple sources
2. **Prioritization:** Weight by frequency, severity, and business impact
3. **Root Cause Analysis:** Understand underlying needs, not just stated wants
4. **Solution Ideation:** Generate multiple approaches to address needs
5. **Validation:** Test assumptions with prototypes or MVPs

**Jobs-to-be-Done Framework:**
```
When [situation],
I want to [motivation],
So I can [expected outcome]

Example:
When I'm reviewing quarterly performance,
I want to quickly compare metrics across regions,
So I can identify which markets need attention
```

### Research Documentation

**Research Summary Template:**
```markdown
## Research Overview
- Method: [Survey/Interviews/Analytics]
- Sample: [Number of participants, demographics]
- Dates: [When conducted]
- Goal: [What you wanted to learn]

## Key Findings
1. [Finding with supporting data]
2. [Finding with supporting data]
3. [Finding with supporting data]

## Insights & Implications
- Insight 1 → Product implication
- Insight 2 → Product implication

## Recommendations
1. [Actionable recommendation]
2. [Actionable recommendation]

## Next Steps
- [Follow-up research needed]
- [Decisions to be made]
```

## Research Pitfalls to Avoid

**Common Mistakes:**
- **Confirmation bias:** Only looking for data that supports your hypothesis
- **Small sample size:** Drawing conclusions from too few data points
- **Self-selection bias:** Only talking to vocal users or advocates
- **Leading questions:** Asking questions that guide respondents to specific answers
- **Ignoring context:** Not understanding the full picture of user behavior
- **Analysis paralysis:** Gathering endless data without taking action

**Quality Checks:**
- Is the sample representative?
- Are you asking unbiased questions?
- Have you triangulated with multiple sources?
- Are you confusing correlation with causation?
- Have you considered alternative explanations?

## Continuous Learning

**Research Cadence:**
- **Weekly:** Review support tickets and feedback
- **Monthly:** Analyze usage metrics and trends
- **Quarterly:** Deep dive research (surveys or interviews)
- **Bi-annually:** Comprehensive market analysis

**Building Research Culture:**
- Share insights regularly with team
- Involve team in research sessions
- Make data accessible
- Celebrate learning from failures
- Encourage experimentation
